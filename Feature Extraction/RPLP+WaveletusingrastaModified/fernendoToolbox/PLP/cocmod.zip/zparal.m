%--Z1//Z2:
%--Z= (Z1.*Z2)./(Z1+Z2);
function Z= zparal(Z1,Z2)

Z= (Z1.*Z2)./(Z1+Z2);
